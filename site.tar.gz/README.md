# Framework
Install:
```
composer create-project -s dev slaxweb/framework
```

It has only a router and a view library. Everything else is up to you.
