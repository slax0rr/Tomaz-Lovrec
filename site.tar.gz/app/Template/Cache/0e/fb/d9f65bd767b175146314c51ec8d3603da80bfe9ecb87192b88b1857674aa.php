<?php

/* LandingPad.html */
class __TwigTemplate_0efbd9f65bd767b175146314c51ec8d3603da80bfe9ecb87192b88b1857674aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Landing Pad
";
    }

    public function getTemplateName()
    {
        return "LandingPad.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
