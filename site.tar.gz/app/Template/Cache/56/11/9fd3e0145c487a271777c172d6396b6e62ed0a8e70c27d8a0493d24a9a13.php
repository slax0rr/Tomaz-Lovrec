<?php

/* Layout/LandingPad.html */
class __TwigTemplate_56119fd3e0145c487a271777c172d6396b6e62ed0a8e70c27d8a0493d24a9a13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>Tomaz Lovrec - Landing Pad</title>
</head>
<body>
    <div class=\"gangsta-wrappa\">
        <div class=\"content\">
            ";
        // line 10
        $this->env->resolveTemplate((isset($context["content"]) ? $context["content"] : null))->display(array_merge($context, (isset($context["contentData"]) ? $context["contentData"] : null)));
        // line 11
        echo "        </div>
    </div>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "Layout/LandingPad.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 11,  30 => 10,  19 => 1,);
    }
}
