<?php
use SlaxWeb\Hooks\Hooks;

/**
 * Example hook
 */
Hooks::set(["name" => "Hook name", "class" => "\\Hooks\\Sample"]);
