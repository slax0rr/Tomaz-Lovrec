<?php
namespace View;

class HelloWorld extends \SlaxWeb\View\View
{

}
