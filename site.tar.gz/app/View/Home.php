<?php
namespace View;

use View\Layout\Primary as Layout;

class Home extends Layout
{

}
